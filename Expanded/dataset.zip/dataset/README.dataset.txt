# Geometric Shapes > 2024-08-04 4:24pm
https://universe.roboflow.com/visao/geometric-shapes-5hwwu

Provided by a Roboflow user
License: CC BY 4.0

